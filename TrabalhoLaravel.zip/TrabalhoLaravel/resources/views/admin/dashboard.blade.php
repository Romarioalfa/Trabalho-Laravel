@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Painelde administração</h1>
        <p>Bem-vindo, administrador.</p>
    </div>
@endsection