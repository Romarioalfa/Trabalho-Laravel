@extends('app')
@section('title', 'Categoria')
@section('content')
<h1>Categoria</h1>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>

        </tr>
    </thead>
    <tbody>
        @foreach($categorias as $categoria)
        <tr>
            <td>{{ $categoria->id }}</td>
            <td>{{ $categoria->nome }}</td>
            <td>
                <a href="{{ route('categorias.show', $categoria) }}">
                    {{$categoria->nome}}
                </a>
                <br>
                <a class="btn btn-primary" href="{{ route('categorias.edit', $categoria) }}">
                    Atualizar
                </a> <br>

                <form action="{{ route('categorias.destroy', $categoria) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button
                        class="btn btn-danger"
                        type="subtmit"
                        onclick="return confirm('Tem certeza que deseja excluir?')">
                        Apagar
                    </button>
                </form>

            </td>
        </tr>
        @endforeach
    </tbody>
</table>


<a class="btn btn-success" href="{{ route('categorias.create') }}">Nova Categoria</a>

@endsection