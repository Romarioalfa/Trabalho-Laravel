<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Tarefa;
use Illuminate\Http\Request;

class TarefaController extends Controller
{
   
    public function index()
    {
        $tarefas = Tarefa::all();
        return view('tarefas.index', compact('tarefas'));
    }

    
    public function show(int $id)
    {
        $tarefa = Tarefa::findOrFail($id);
        return view('tarefas.show', compact('tarefa'));
    }

    
    public function create()
    {
        $categorias = Categoria::all(); 
        return view('tarefas.create', compact('categorias'));
    }

    
    public function store(Request $request)
    {
        $dados = $request->validate([
            'titulo' => 'required|string|max:255',
            'descricao' => 'nullable|string',
            'concluido' => 'required|boolean',
            'categoria_id' => 'required|exists:categorias,id',
        ]);

        Tarefa::create($dados);

        return redirect()->route('tarefas.index')->with('success', 'Tarefa criada com sucesso!');
    }

    
    public function edit(int $id)
    {
        $tarefa = Tarefa::findOrFail($id);
        $categorias = Categoria::all();
        return view('tarefas.edit', compact('tarefa', 'categorias'));
    }

    
    public function update(int $id, Request $request)
    {
        $tarefa = Tarefa::findOrFail($id);

        $dados = $request->validate([
            'titulo' => 'required|string|max:255',
            'descricao' => 'nullable|string',
            'concluido' => 'required|boolean',
            'categoria_id' => 'required|exists:categorias,id',
        ]);

        $tarefa->update($dados);

        return redirect()->route('tarefas.index')->with('success', 'Tarefa atualizada com sucesso!');
    }

    
    public function destroy(int $id)
    {
        $tarefa = Tarefa::findOrFail($id);
        $tarefa->delete();

        return redirect()->route('tarefas.index')->with('success', 'Tarefa excluída com sucesso!');
    }
}
