@extends('app')
@section('title', 'Editar Tarefas')
@section('content')
<h1>Editar Tarefas</h1>
<form action="{{ route('tarefas.update', $tarefa) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="mb-3">
        <label for="titulo" class="form-label">Titulo</label>
        <input value="{{$tarefa->titulo}}" type="text" id="titulo" class="form-control" name="titulo" placeholder="digite o seu titulo">
    </div>

    <div class="mb-3">
        <label for="descricao" class="form-label">Descrição</label>
        <input value="{{$tarefa->descricao}}" type="text" id="descricao" class="form-control" name="descricao" placeholder="digite o sua descricao">
    </div>

    <div class="mb-3">
        <label for="concluido" class="form-label">Concluído</label>
        <select name="concluido" id="concluido" class="form-control" required>
            <option value="0" {{ $tarefa->concluido == 0 ? 'selected' : '' }}>Não</option>
            <option value="1" {{ $tarefa->concluido == 1 ? 'selected' : '' }}>Sim</option>
        </select>
    </div>

    {{-- NOVIDADE CRÍTICA: Adição do campo categoria_id, exigido pelo seu controlador. --}}
    <div class="mb-3">
        <label for="categoria_id" class="form-label">Categoria</label>
        <select name="categoria_id" id="categoria_id" class="form-control" required>
            @foreach ($categorias as $categoria)
                <option value="{{ $categoria->id }}"
                    {{ $tarefa->categoria_id == $categoria->id ? 'selected' : '' }}>
                    {{ $categoria->nome }}
                </option>
            @endforeach
        </select>
    </div>

    <button class="btn btn-success" type="submit">Enviar</button>
</form>
@endsection
