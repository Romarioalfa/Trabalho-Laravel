
<?php $__env->startSection('title', 'Lista de tarefas'); ?>
<?php $__env->startSection('content'); ?>
<h1>Lista de tarefas</h1>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tiutlo</th>
            <th>Descrição</th>
            <th>Concluído</th>
        </tr>
    </thead>  
    <tbody>
        <?php $__currentLoopData = $tarefas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarefa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tarefa->id); ?></td>
                <td><?php echo e($tarefa->titulo); ?></td>
                <td><?php echo e($tarefa->descricao); ?></td>
                <td><?php echo e($tarefa->concluido); ?></td>
                <td>
                    <a href="<?php echo e(route('tarefas.show', $tarefa)); ?>">
                        <?php echo e($tarefa->titulo); ?>

                    </a>
                    <br>
                    <a class="btn btn-primary" href="<?php echo e(route('tarefas.edit', $tarefa)); ?>">
                        Atualizar
                    </a> <br>
                    
                    <form action="<?php echo e(route('tarefas.destroy', $tarefa)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button 
                            class="btn btn-danger" 
                            type="subtmit" 
                            onclick="return confirm('Tem certeza que deseja excluir?')"
                        >
                            Apagar
                        </button>
                    </form>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>  
</table>

<a class="btn btn-success" href="<?php echo e(route('tarefas.create')); ?>">Novas Tarefas</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Romario\Desktop\laravel0001-main\laravel0001-main\projeto01 - Copia\projeto01 - Copia\resources\views/tarefas/index.blade.php ENDPATH**/ ?>