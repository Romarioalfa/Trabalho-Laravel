

<?php $__env->startSection('title', 'Lista de Tarefas'); ?>

<?php $__env->startSection('content'); ?>
<h1>Nova Tarefa</h1>

<form action="<?php echo e(route('tarefas.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label for="titulo" class="form-label">Título</label>
        <input type="text" id="titulo" class="form-control" name="titulo" placeholder="Digite o título">
    </div>

    <div class="mb-3">
        <label for="descricao" class="form-label">Descrição</label>
        <input type="text" id="descricao" class="form-control" name="descricao" placeholder="Digite a descrição">
    </div>

    <div class="mb-3">
        <label for="concluido" class="form-label">Concluído</label>
        <select id="concluido" class="form-control" name="concluido">
            <option value="0">Não</option>
            <option value="1">Sim</option>
        </select>
    </div>

    
    <div class="mb-3">
        <label for="categoria_id" class="form-label">Categoria</label>
        <select id="categoria_id" class="form-control" name="categoria_id" required>
            <option value="">Selecione uma categoria</option>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nome); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button class="btn btn-success" type="submit">Enviar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\UniALFA\Desktop\2025108_21526_projeto01 - Copia\projeto01 - Copia\resources\views/tarefas/create.blade.php ENDPATH**/ ?>