@extends('app')

@section('title', 'Lista de Tarefas')

@section('content')
<h1>Nova Tarefa</h1>

<form action="{{ route('tarefas.store') }}" method="POST">
    @csrf

    <div class="mb-3">
        <label for="titulo" class="form-label">Título</label>
        <input type="text" id="titulo" class="form-control" name="titulo" placeholder="Digite o título">
    </div>

    <div class="mb-3">
        <label for="descricao" class="form-label">Descrição</label>
        <input type="text" id="descricao" class="form-control" name="descricao" placeholder="Digite a descrição">
    </div>

    <div class="mb-3">
        <label for="concluido" class="form-label">Concluído</label>
        <select id="concluido" class="form-control" name="concluido">
            <option value="0">Não</option>
            <option value="1">Sim</option>
        </select>
    </div>

    {{-- 👇 Campo de seleção de categoria --}}
    <div class="mb-3">
        <label for="categoria_id" class="form-label">Categoria</label>
        <select id="categoria_id" class="form-control" name="categoria_id" required>
            <option value="">Selecione uma categoria</option>
            @foreach ($categorias as $categoria)
                <option value="{{ $categoria->id }}">{{ $categoria->nome }}</option>
            @endforeach
        </select>
    </div>

    <button class="btn btn-success" type="submit">Enviar</button>
</form>
@endsection
