
<?php $__env->startSection('title', 'Nova Categoria'); ?>
<?php $__env->startSection('content'); ?>
<h1>Nova Categoria</h1>
<form action="<?php echo e(route('categorias.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="nome" class="form-label">Nome</label>
        <input type="text" id="nome" class="form-control" name="nome" placeholder="digite o seu nome">
    </div>


    <button class="btn btn-success" type="submit">Enviar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\UniALFA\Desktop\2025108_21526_projeto01 - Copia\projeto01 - Copia\resources\views/categorias/create.blade.php ENDPATH**/ ?>