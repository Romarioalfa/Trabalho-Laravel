<?php $__env->startSection('title', 'Editar Tarefas'); ?>
<?php $__env->startSection('content'); ?>
<h1>Editar Tarefas</h1>
<form action="<?php echo e(route('tarefas.update', $tarefa)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="titulo" class="form-label">Titulo</label>
        
        <input value="<?php echo e($tarefa->titulo); ?>" type="text" id="titulo" class="form-control" name="titulo" placeholder="digite o seu titulo">
    </div>

    <div class="mb-3">
        <label for="descricao" class="form-label">Descrição</label>
        <input value="<?php echo e($tarefa->descricao); ?>" type="text" id="descricao" class="form-control" name="descricao" placeholder="digite o sua descricao">
    </div>

    <div class="mb-3">
        <label for="concluido" class="form-label">Concluído</label>
        
        <select name="concluido" id="concluido" class="form-control" required>
            <option value="0" <?php echo e($tarefa->concluido == 0 ? 'selected' : ''); ?>>Não</option>
            <option value="1" <?php echo e($tarefa->concluido == 1 ? 'selected' : ''); ?>>Sim</option>
        </select>
    </div>

    
    <div class="mb-3">
        <label for="categoria_id" class="form-label">Categoria</label>
        <select name="categoria_id" id="categoria_id" class="form-control" required>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria->id); ?>"
                    <?php echo e($tarefa->categoria_id == $categoria->id ? 'selected' : ''); ?>>
                    <?php echo e($categoria->nome); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button class="btn btn-success" type="submit">Enviar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Romario\Desktop\laravel0001-main\laravel0001-main\projeto01 - Copia\projeto01 - Copia\resources\views/tarefas/edit.blade.php ENDPATH**/ ?>