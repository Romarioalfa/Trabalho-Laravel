@extends('app')
@section('title', 'Lista de tarefas')
@section('content')
<h1>Lista de tarefas</h1>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tiutlo</th>
            <th>Descrição</th>
            <th>Concluído</th>
        </tr>
    </thead>  
    <tbody>
        @foreach($tarefas as $tarefa)
            <tr>
                <td>{{ $tarefa->id }}</td>
                <td>{{ $tarefa->titulo }}</td>
                <td>{{ $tarefa->descricao }}</td>
                <td>{{ $tarefa->concluido }}</td>
                <td>
                    <a href="{{ route('tarefas.show', $tarefa) }}">
                        {{$tarefa->titulo}}
                    </a>
                    <br>
                    <a class="btn btn-primary" href="{{ route('tarefas.edit', $tarefa) }}">
                        Atualizar
                    </a> <br>
                    
                    <form action="{{ route('tarefas.destroy', $tarefa) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button 
                            class="btn btn-danger" 
                            type="subtmit" 
                            onclick="return confirm('Tem certeza que deseja excluir?')"
                        >
                            Apagar
                        </button>
                    </form>

                </td>
            </tr>
        @endforeach
    </tbody>  
</table>

<a class="btn btn-success" href="{{ route('tarefas.create') }}">Novas Tarefas</a>
@endsection

