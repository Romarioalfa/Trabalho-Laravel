@extends('app')
@section('title', 'Detalhe das Tarefas')
@section('content')
<div class="card">
    <div class="card-header">
        Detalhes das Tarefas: {{ $tarefa->titulo }}
    </div>
    <div class="card-body">
        <p><strong>ID:</strong> {{ $tarefa->id }}</p>
        <p><strong>Titulo:</strong> {{ $tarefa->titulo }}</p>
        <p><strong>Descrição:</strong> {{ $tarefa->descricao }}</p>
        <p><strong>Concluído:</strong> {{ $tarefa->concluido }}</p>
    
        <a class="btn btn-success" href="/tarefas">
            Voltar para a lista de tarefas
        </a>
    </div>
</div>
@endsection
