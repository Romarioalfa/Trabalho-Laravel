<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;

class CategoriaController extends Controller
{
    public function index()
    {
        $Categorias = Categoria::get();
        return view('categorias.index', [
            'categorias' => $Categorias
        ]);
    }

    public function show(int $id)
    {
        $categoria = Categoria::find($id);

        return view('categorias.show', [
            'categoria' => $categoria
        ]);
    }

    public function create()
    {
        $categorias = Categoria::all(); 
        return view('categorias.create', compact('categorias')); 
    }

    public function store(Request $request)
    {
        $dados = $request->except('_token');

        Categoria::create($dados);

        return redirect('/categorias');
    }

    public function edit(int $id)
    {
        $categoria = Categoria::find($id);

        return view('categorias.edit', [
            'categoria' => $categoria
        ]);
    }

    public function update(int $id, Request $request)
    {
        $categoria = Categoria::find($id);

        $categoria->update([
            'nome' => $request->nome,
        ]);

        return redirect('/categorias');
    }

    public function destroy(int $id)
    {
        $categoria = Categoria::find($id);
        $categoria->delete();
        return redirect('/categorias');
    }
}
