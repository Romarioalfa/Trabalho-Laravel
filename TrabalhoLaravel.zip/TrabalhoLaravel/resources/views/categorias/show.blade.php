@extends('app')
@section('title', 'Detalhe da categoria')
@section('content')
<div class="card">
    <div class="card-header">
        Detalhes da Categoria: {{ $categoria->nome }}
    </div>
    <div class="card-body">
        <p><strong>ID:</strong> {{ $categoria->id }}</p>
        <p><strong>Nome:</strong> {{ $categoria->nome }}</p>
        
        <a class="btn btn-success" href="/categorias">
            Voltar para Categoria
        </a>
    </div>
</div>
@endsection
