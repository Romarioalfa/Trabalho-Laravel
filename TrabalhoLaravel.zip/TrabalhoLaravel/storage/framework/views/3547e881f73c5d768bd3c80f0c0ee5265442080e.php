
<?php $__env->startSection('title', 'Categoria'); ?>
<?php $__env->startSection('content'); ?>
<h1>Categoria</h1>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($categoria->id); ?></td>
            <td><?php echo e($categoria->nome); ?></td>
            <td>
                <a href="<?php echo e(route('categorias.show', $categoria)); ?>">
                    <?php echo e($categoria->nome); ?>

                </a>
                <br>
                <a class="btn btn-primary" href="<?php echo e(route('categorias.edit', $categoria)); ?>">
                    Atualizar
                </a> <br>

                <form action="<?php echo e(route('categorias.destroy', $categoria)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button
                        class="btn btn-danger"
                        type="subtmit"
                        onclick="return confirm('Tem certeza que deseja excluir?')">
                        Apagar
                    </button>
                </form>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<a class="btn btn-success" href="<?php echo e(route('categorias.create')); ?>">Nova Categoria</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Romario\Desktop\laravel0001-main\laravel0001-main\projeto01 - Copia\projeto01 - Copia\resources\views/categorias/index.blade.php ENDPATH**/ ?>